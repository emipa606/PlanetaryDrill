﻿namespace SquirtingElephant.PlanetaryDrill
{
    public static class Constants
    {
        public const string GLITTER_TECH_MOD_NAME = "Glitter Tech";
        public const string SETTINGS_PREFIX = "SEPD_";
        public const int CHUNK_WORK_AMOUNT = 250;
    }
}
